function calculateAverage() {
	// Arrays to store grades and credits
	var grades = [];
	var credits = [];

	// Function to convert grade to GPA
	function gradeToGPA(grade) {
		switch (grade.toUpperCase()) {
			case 'A':
				return 4.0;
			case 'B':
				return 3.0;
			case 'C':
				return 2.0;
			// Add more cases as needed
			default:
				return 0.0;
		}
		console.log("yes1")
	}

	// Loop through each course to get grades and credits
	for (var i = 1; i <= 5; i++) {
		var grade = document.getElementById('course' + i + 'Grade').value.trim();
		var credit = parseFloat(document.getElementById('course' + i + 'Credits').value.trim());

		// Check if both grade and credit are provided
		if (grade !== '' && !isNaN(credit)) {
			grades.push(gradeToGPA(grade) * credit);
			credits.push(credit);
		}
		console.log(grade);
	}

	// Check if at least three grades are entered
	if (grades.length >= 3) {
		var totalPoints = grades.reduce((a, b) => a + b, 0);
		var totalCredits = credits.reduce((a, b) => a + b, 0);

		var averageGPA = totalPoints / totalCredits;

		// Display the average GPA
		document.getElementById('averageGPA').value = averageGPA.toFixed(2);
	} else {
		alert("Please enter at least three grades with credits.");
		console.log("why")
	}
}